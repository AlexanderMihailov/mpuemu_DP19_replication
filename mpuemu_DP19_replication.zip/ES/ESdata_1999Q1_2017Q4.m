% MATLAB program: ESdata_1999Q1_2017Q4.m
%         The code is used for the working paper "Heterogeneous Effects of Single Monetary Policy on Unemployment
%         Rates in the Largest EMU Countries", by Alexander Mihailov,Giovanni Razzu and Zhe Wang.
%         To be RUN FIRST, before estimation and simulation, to create the data in *.mat format.
% Latest modification: 181012, by Alexander Mihailov

%%
clc
tic

%% Spain, 1999Q1-2017Q4 (76 obs) - no need to select subsamples below, done in the Dynare code

data=xlsread('ESdata_1999Q1_2017Q4.xls','data','U41:AB116');  % Estimation from 1999Q1 to 2017Q4 (76 obs)
%data=xlsread('ESdata_1999Q1_2017Q4.xls','data','U41:AB74');  % Estimation from 1999Q1 to 2007Q2 (34 obs)
%AM181012 This sample split avoids the most turbulent period of the Global Financial Crisis 2007Q3-2009Q2 (8 obs)
%data=xlsread('ESdata_1999Q1_2017Q4.xls','data','U83:AB116'); % Estimation from 2009Q2 to 2017Q4 (34 obs)

dc=data(:, 1); 
dinve=data(:,2);
dy=data(:,3);
N=data(:,4);
pinfobs=data(:,5);
dwEC=data(:,6);
robs=data(:,7);
URlog=data(:,8);

%% Saves the data in *.mat format

save ESdata_2017Q4 dc dinve dy N pinfobs dwEC robs URlog
