﻿README file for replicating the estimation and simulation results in the working paper
"Heterogeneous Effects of Single Monetary Policy on Unemployment Rates in the Largest EMU Countries",
by Alexander Mihailov,Giovanni Razzu and Zhe Wang.

README.txt
E:\archive\comp\dynare\work\zhe\nbb\code_4_countries

AM181012

For each of the countries (and for the full sample as well as the two subsamples by country):

1. Run first the MATLAB file that reads the data from the *.xls spreadsheet and converts them into *.mat format: XXdata_1999Q1_2017Q4.m, where XX stands for a country in the sample, FR, DE, IT, ES.

2. Run now only the first "estimation()" command in the Dynare file XX_amEC.mod, to create the "mode_file" option used in the second "estimation()" command.

3. Finally, run the second "estimation()" command and the 3 commands that follow it, to perform Bayesian estimation using the RWMH-MCMC algorithm with 1000000 draws (and the first 20% discarded), with subsequent simulation.
